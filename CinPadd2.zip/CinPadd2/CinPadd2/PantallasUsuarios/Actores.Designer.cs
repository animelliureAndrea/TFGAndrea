﻿namespace CinPadd2.PantallasUsuarios
{
    partial class Actores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Actores));
            this.btnSeleccion = new System.Windows.Forms.Button();
            this.Castings = new System.Windows.Forms.GroupBox();
            this.lblPeli = new System.Windows.Forms.Label();
            this.dtpFecha = new System.Windows.Forms.DateTimePicker();
            this.lblUbicacion = new System.Windows.Forms.Label();
            this.lblDirector = new System.Windows.Forms.Label();
            this.lblDescripcion = new System.Windows.Forms.Label();
            this.lblNombre = new System.Windows.Forms.Label();
            this.btnPelis = new System.Windows.Forms.Button();
            this.btnNo = new System.Windows.Forms.Button();
            this.btnSi = new System.Windows.Forms.Button();
            this.btnPerfil = new System.Windows.Forms.Button();
            this.btnFestival = new System.Windows.Forms.Button();
            this.Castings.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSeleccion
            // 
            this.btnSeleccion.Location = new System.Drawing.Point(573, 378);
            this.btnSeleccion.Margin = new System.Windows.Forms.Padding(4);
            this.btnSeleccion.Name = "btnSeleccion";
            this.btnSeleccion.Size = new System.Drawing.Size(121, 28);
            this.btnSeleccion.TabIndex = 12;
            this.btnSeleccion.Text = "Seleccionados";
            this.btnSeleccion.UseVisualStyleBackColor = true;
            this.btnSeleccion.Click += new System.EventHandler(this.btnSeleccion_Click);
            // 
            // Castings
            // 
            this.Castings.BackColor = System.Drawing.Color.DarkMagenta;
            this.Castings.Controls.Add(this.lblPeli);
            this.Castings.Controls.Add(this.dtpFecha);
            this.Castings.Controls.Add(this.lblUbicacion);
            this.Castings.Controls.Add(this.lblDirector);
            this.Castings.Controls.Add(this.lblDescripcion);
            this.Castings.Controls.Add(this.lblNombre);
            this.Castings.Location = new System.Drawing.Point(149, 31);
            this.Castings.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Castings.Name = "Castings";
            this.Castings.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Castings.Size = new System.Drawing.Size(929, 300);
            this.Castings.TabIndex = 11;
            this.Castings.TabStop = false;
            this.Castings.Text = "Castings";
            // 
            // lblPeli
            // 
            this.lblPeli.AutoSize = true;
            this.lblPeli.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPeli.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblPeli.Location = new System.Drawing.Point(40, 250);
            this.lblPeli.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPeli.Name = "lblPeli";
            this.lblPeli.Size = new System.Drawing.Size(60, 22);
            this.lblPeli.TabIndex = 5;
            this.lblPeli.Text = "label1";
            // 
            // dtpFecha
            // 
            this.dtpFecha.Location = new System.Drawing.Point(424, 34);
            this.dtpFecha.Margin = new System.Windows.Forms.Padding(4);
            this.dtpFecha.Name = "dtpFecha";
            this.dtpFecha.Size = new System.Drawing.Size(265, 22);
            this.dtpFecha.TabIndex = 4;
            // 
            // lblUbicacion
            // 
            this.lblUbicacion.AutoSize = true;
            this.lblUbicacion.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUbicacion.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblUbicacion.Location = new System.Drawing.Point(40, 159);
            this.lblUbicacion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUbicacion.Name = "lblUbicacion";
            this.lblUbicacion.Size = new System.Drawing.Size(60, 22);
            this.lblUbicacion.TabIndex = 3;
            this.lblUbicacion.Text = "label1";
            // 
            // lblDirector
            // 
            this.lblDirector.AutoSize = true;
            this.lblDirector.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDirector.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblDirector.Location = new System.Drawing.Point(40, 199);
            this.lblDirector.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDirector.Name = "lblDirector";
            this.lblDirector.Size = new System.Drawing.Size(60, 22);
            this.lblDirector.TabIndex = 2;
            this.lblDirector.Text = "label1";
            // 
            // lblDescripcion
            // 
            this.lblDescripcion.AutoSize = true;
            this.lblDescripcion.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescripcion.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblDescripcion.Location = new System.Drawing.Point(40, 88);
            this.lblDescripcion.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDescripcion.Name = "lblDescripcion";
            this.lblDescripcion.Size = new System.Drawing.Size(60, 22);
            this.lblDescripcion.TabIndex = 1;
            this.lblDescripcion.Text = "label1";
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre.ForeColor = System.Drawing.Color.SteelBlue;
            this.lblNombre.Location = new System.Drawing.Point(25, 30);
            this.lblNombre.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(74, 26);
            this.lblNombre.TabIndex = 0;
            this.lblNombre.Text = "label1";
            // 
            // btnPelis
            // 
            this.btnPelis.Image = global::CinPadd2.Properties.Resources.claqueta_cine_22527;
            this.btnPelis.Location = new System.Drawing.Point(33, 499);
            this.btnPelis.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnPelis.Name = "btnPelis";
            this.btnPelis.Size = new System.Drawing.Size(77, 82);
            this.btnPelis.TabIndex = 6;
            this.btnPelis.UseVisualStyleBackColor = true;
            this.btnPelis.Click += new System.EventHandler(this.btnPelis_Click);
            // 
            // btnNo
            // 
            this.btnNo.Image = global::CinPadd2.Properties.Resources.bton_noNo;
            this.btnNo.Location = new System.Drawing.Point(885, 348);
            this.btnNo.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnNo.Name = "btnNo";
            this.btnNo.Size = new System.Drawing.Size(91, 89);
            this.btnNo.TabIndex = 10;
            this.btnNo.UseVisualStyleBackColor = true;
            this.btnNo.Click += new System.EventHandler(this.btnNo_Click);
            // 
            // btnSi
            // 
            this.btnSi.Image = global::CinPadd2.Properties.Resources.btón_siSi;
            this.btnSi.Location = new System.Drawing.Point(268, 348);
            this.btnSi.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnSi.Name = "btnSi";
            this.btnSi.Size = new System.Drawing.Size(91, 89);
            this.btnSi.TabIndex = 8;
            this.btnSi.UseVisualStyleBackColor = true;
            this.btnSi.Click += new System.EventHandler(this.btnSi_Click);
            // 
            // btnPerfil
            // 
            this.btnPerfil.Image = global::CinPadd2.Properties.Resources.botón_perfil;
            this.btnPerfil.Location = new System.Drawing.Point(1087, 499);
            this.btnPerfil.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnPerfil.Name = "btnPerfil";
            this.btnPerfil.Size = new System.Drawing.Size(77, 82);
            this.btnPerfil.TabIndex = 9;
            this.btnPerfil.UseVisualStyleBackColor = true;
            this.btnPerfil.Click += new System.EventHandler(this.btnPerfil_Click);
            // 
            // btnFestival
            // 
            this.btnFestival.Image = global::CinPadd2.Properties.Resources.botón_festival;
            this.btnFestival.Location = new System.Drawing.Point(590, 499);
            this.btnFestival.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnFestival.Name = "btnFestival";
            this.btnFestival.Size = new System.Drawing.Size(77, 82);
            this.btnFestival.TabIndex = 7;
            this.btnFestival.UseVisualStyleBackColor = true;
            this.btnFestival.Click += new System.EventHandler(this.btnFestival_Click);
            // 
            // Actores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SteelBlue;
            this.ClientSize = new System.Drawing.Size(1176, 609);
            this.Controls.Add(this.btnSeleccion);
            this.Controls.Add(this.Castings);
            this.Controls.Add(this.btnNo);
            this.Controls.Add(this.btnSi);
            this.Controls.Add(this.btnPerfil);
            this.Controls.Add(this.btnFestival);
            this.Controls.Add(this.btnPelis);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Actores";
            this.Text = "Actores";
            this.Load += new System.EventHandler(this.Actores_Load);
            this.Castings.ResumeLayout(false);
            this.Castings.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSeleccion;
        private System.Windows.Forms.GroupBox Castings;
        private System.Windows.Forms.DateTimePicker dtpFecha;
        private System.Windows.Forms.Label lblUbicacion;
        private System.Windows.Forms.Label lblDirector;
        private System.Windows.Forms.Label lblDescripcion;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.Button btnNo;
        private System.Windows.Forms.Button btnSi;
        private System.Windows.Forms.Button btnPerfil;
        private System.Windows.Forms.Button btnFestival;
        private System.Windows.Forms.Button btnPelis;
        private System.Windows.Forms.Label lblPeli;
    }
}